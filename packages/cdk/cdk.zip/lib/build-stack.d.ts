import { App, Stack, StackProps } from 'monocdk';
import { GitHubSourceActionProps, CodeCommitSourceActionProps } from 'monocdk/aws-codepipeline-actions';
import { IKey } from 'monocdk/aws-kms';
export interface CodeCommitProps {
    readonly codeCommitSourceActionProps: CodeCommitSourceActionProps;
    readonly repositoryName: string;
    readonly repositoryDescription?: string;
}
export interface BuildStackProps extends StackProps {
    readonly stageRegionMap: {
        [key: string]: string[];
    };
    readonly githubProps?: GitHubSourceActionProps;
    readonly codeCommitProps?: CodeCommitProps;
    readonly websiteDomainName: string;
}
export declare class BuildStack extends Stack {
    readonly artifactBucketEncryptionKey?: IKey;
    readonly githubSourceActionProps?: GitHubSourceActionProps;
    readonly codeCommitProps?: CodeCommitProps;
    readonly websiteDomainName: string;
    constructor(parent: App, name: string, props: BuildStackProps);
}
