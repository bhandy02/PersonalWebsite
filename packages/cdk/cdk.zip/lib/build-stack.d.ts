import { App, Stack, StackProps } from 'aws-cdk-lib';
import { GitHubSourceActionProps, CodeCommitSourceActionProps } from 'aws-cdk-lib/aws-codepipeline-actions';
import { IKey } from 'aws-cdk-lib/aws-kms';
export interface CodeCommitProps {
    readonly codeCommitSourceActionProps: CodeCommitSourceActionProps;
    readonly repositoryName: string;
    readonly repositoryDescription?: string;
}
export interface BuildStackProps extends StackProps {
    readonly stageRegionMap: {
        [key: string]: string[];
    };
    readonly githubProps?: GitHubSourceActionProps;
    readonly codeCommitProps?: CodeCommitProps;
    readonly websiteDomainName: string;
    readonly projectName: string;
}
export declare class BuildStack extends Stack {
    readonly artifactBucketEncryptionKey?: IKey;
    readonly githubSourceActionProps?: GitHubSourceActionProps;
    readonly codeCommitProps?: CodeCommitProps;
    readonly websiteDomainName: string;
    constructor(parent: App, name: string, props: BuildStackProps);
}
