import { App, Stack, StackProps } from 'aws-cdk-lib';
export declare class PersonalWebsiteStack extends Stack {
    constructor(scope: App, id: string, props?: StackProps);
}
