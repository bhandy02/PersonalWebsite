import { App, Stack, StackProps } from 'monocdk';
export declare class PersonalWebsiteStack extends Stack {
    constructor(scope: App, id: string, props?: StackProps);
}
