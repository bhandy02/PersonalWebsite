import { Construct } from 'constructs';
export interface CloudFrontInvalidationFunctionProps {
    readonly distributionId: string;
}
export declare class CloudfrontInvalidationFunction extends Construct {
    constructor(parent: Construct, name: string, props: CloudFrontInvalidationFunctionProps);
}
