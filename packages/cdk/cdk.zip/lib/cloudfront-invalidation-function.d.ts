import { Construct } from 'monocdk';
export interface CloudFrontInvalidationFunctionProps {
    readonly distributionId: string;
}
export declare class CloudfrontInvalidationFunction extends Construct {
    constructor(parent: Construct, name: string, props: CloudFrontInvalidationFunctionProps);
}
