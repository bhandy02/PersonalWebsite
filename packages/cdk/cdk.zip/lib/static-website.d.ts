import { Construct } from 'monocdk';
import { Bucket } from 'monocdk/aws-s3';
import { CodebuildWebsiteArtifactConfiguration } from './website-artifact-location-configuration';
import { Distribution } from 'monocdk/aws-cloudfront';
export interface StaticWebsiteProps {
    websiteDomainName: string;
    websiteArtifactCopyConfiguration: CodebuildWebsiteArtifactConfiguration;
}
export declare class StaticWebsite extends Construct {
    readonly bucket: Bucket;
    readonly distribution: Distribution;
    readonly websiteDomainName: string;
    constructor(parent: Construct, name: string, props: StaticWebsiteProps);
}
