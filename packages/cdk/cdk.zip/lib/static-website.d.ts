import { Construct } from 'constructs';
import { Bucket } from 'aws-cdk-lib/aws-s3';
import { CodebuildWebsiteArtifactConfiguration } from './website-artifact-location-configuration';
import { Distribution } from 'aws-cdk-lib/aws-cloudfront';
export interface StaticWebsiteProps {
    websiteArtifactCopyConfiguration: CodebuildWebsiteArtifactConfiguration;
    s3BucketSuffix: string;
}
export declare class StaticWebsite extends Construct {
    readonly bucket: Bucket;
    readonly distribution: Distribution;
    constructor(parent: Construct, name: string, props: StaticWebsiteProps);
}
