import { IBucket } from 'aws-cdk-lib/aws-s3';
import { CfnParameter } from 'aws-cdk-lib';
import { Construct } from 'constructs';
export declare class CodeBuildConstants {
    static readonly CODE_BUILD_BUCKET_PARAM: string;
    static readonly CODE_BUILD_KEY_PARAM: string;
}
export interface WebsiteArtifactLocationConfiguration {
    websiteCopyConfiguration(): ArtifactCopyConfiguration;
}
export declare class CodebuildArtifactLocationProvider {
    readonly parent: Construct;
    private readonly stack;
    private readonly importBucketName;
    constructor(parent: Construct);
    bucket(): IBucket;
    key(): CfnParameter;
}
export interface ArtifactCopyConfiguration {
    sourceBucket: IBucket;
    sourceKey: string;
    zipSubFolder: string;
}
export declare class CodebuildWebsiteArtifactConfiguration implements WebsiteArtifactLocationConfiguration {
    readonly parent: Construct;
    readonly subfolder: string;
    private readonly codeBuildLocationProvider;
    constructor(parent: Construct, subfolder: string);
    websiteCopyConfiguration(): ArtifactCopyConfiguration;
}
