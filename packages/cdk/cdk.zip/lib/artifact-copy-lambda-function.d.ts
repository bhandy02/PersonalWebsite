import { IBucket } from 'monocdk/aws-s3';
import { Construct } from 'monocdk';
export interface IArtifactCopyLambdaFunctionProps {
    /**
     * The destination bucket to copy to.
     */
    destBucket: IBucket;
    /**
     * The source bucket to copy from.
     */
    sourceBucket: IBucket;
    /**
     * The source key to copy.
     * We would normally expect this to be a folder.
     * We'll recursively copy from the sourceKey to the destination.
     *
     * If the source key is a zip archive, we'll extract it, but you must use the
     * @argument sourceKeyIsZipped to let us know.
     */
    sourceKey: string;
    /**
     *
     *
     * The subfolder from within the extracted archive to copy from.
     *
     * @default none
     */
    zipSubFolder: string;
}
/**
 * A construct to copy things during stack modifies.
 * Uses an inline lambda as a custom resource
 */
export declare class ArtifactCopyLambdaFunction extends Construct {
    readonly destBucket: IBucket;
    readonly destPath: string;
    constructor(parent: Construct, name: string, props: IArtifactCopyLambdaFunctionProps);
}
